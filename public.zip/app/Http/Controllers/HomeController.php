<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cookies;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
         $data = Cookies::get()->toArray();
         return view('home',compact('data'));
    }

     public function userdata(Request $request)
    {
        $data = Cookies::where('id' , $request['id'])->first();


    if( !empty($data['cookis_data']))
        $cookie = unserialize($data['cookis_data']);

    foreach ($cookie as $cook ) {   ?>    
    <tr> 
      <td><?php echo $cook['name'] ;?></td>
      <td><?php echo $cook['value']  ;?></td> 
    </tr><?php
   }
}    

   public function delete($id)
   {
        Cookies::where('id' , $id)->delete();
        return redirect()->back();
   }



       
         
  
}
