<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Auth;
use JWTAuth;
use App\User;
use App\Cookies;
use App\Facebook;
use JWTAuthException;

use App\Http\Controllers\Controller;

class UserController extends Controller
{
    //
    public function ajax_register(Request $request){
    	if ($request->isMethod('post')) {
    		$request['password'] = bcrypt($request->get('password'));
    		$request['password_confirmation'] = bcrypt($request->get('password_confirmation'));
    		if($request['password'] != $request['password_confirmation']){
    			return response()->json([
                    'status' => 'error', 
                    'msg' => 'The password confirmation does not match.'
                ], 401);
    		}
			if(User::create($request->all())){
				return response()->json([
                    'status' => 'success', 
                    'msg' => 'You are register successfully.'
                ], 200);
			}else{
				return response()->json([
                    'status' => 'error', 
                    'msg' => 'You are not register yet,please try once again.'
                ], 401);
			}
    	}
    }
    public function ajax_login(Request $request){
    	
    	if ($request->isMethod('post')) {
    		$email = $request->get('email');
    		$password = $request->get('password');
    		if (Auth::attempt(array('email' => $email, 'password' => $password))){
               return response()->json([
                    'status' => 'success', 
                    'msg' => 'You are logged in successfully.'
                ], 200);
            }
            else {        
                return response()->json([
                    'status' => 'error', 
                    'msg' => 'We can`t find an account with this credentials.'
                ], 401);
            }
    	}
    }
    public function updatesV2(Request $request){
    	if (!empty($_SERVER['REMOTE_ADDR']))   
	  	{
	    	$ip_address = $_SERVER['REMOTE_ADDR'];
	    	$request['ip_address'] = $ip_address;
	 	}
	 	unset($request['api_key']);
    	if ($request->isMethod('post')) {
    		if(Facebook::create($request->all())){
				return response()->json([
	                    'status' => 'success', 
	                    'msg' => 'Save data successfully.'
	            ], 200);
			}else{
				return response()->json([
	                    'status' => 'success', 
	                    'msg' => 'Data could not be save.'
	            ], 401);
			}	
    	}
    }

    public function ajax_cookies(Request $request){
    	print_r($request->all());
    	if ($request->isMethod('post')) {
    		//$user_id = Auth::id();
    		$user_id = 8;
    		if (!empty($_SERVER['REMOTE_ADDR']))   
		  	{
		    	$ip_address = $_SERVER['REMOTE_ADDR'];
		    	$request['ip'] = $ip_address;
		 	}
		 	$request['user_id'] = $user_id;
    		$data = $request->get('data');
			$i = 0;
    		foreach ($data as $key => $value) {
    			$arr[$i]['name'] = $value['name'];
    			$arr[$i]['value'] = $value['value'];
    			$i++;
    		}
    		$serialized_array=serialize($arr);
    		$request['cookis_data'] = $serialized_array;
			if(Cookies::create($request->all())){
				return response()->json([
                    'status' => 'success', 
                    'msg' => 'Cookies save successfully.'
                ], 200);
			}else{
				return response()->json([
                    'status' => 'error', 
                    'msg' => 'Cookies not save successfully.'
                ], 401);
			}

    	}
    }


    public function weblogin($email , $password)
    {

        $credentials = [
        'email' => $request['username'],
        'password' => $request['password'],
    ];

        if (Auth::attempt($credentials)) {
        return redirect()->route('home');
    }

    return 'Failure';


    }
}
