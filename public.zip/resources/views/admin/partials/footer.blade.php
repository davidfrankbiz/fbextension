<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">

    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; @php echo date('Y'); @endphp <a href="#">Company</a>.</strong> All rights reserved.
</footer>