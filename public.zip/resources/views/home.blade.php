@extends('admin.layouts.master')

@section('content')

    <div class="row">

     <div class="box">
                 <div class="box-header">
                 </div>
                 <!-- /.box-header -->
                 <div class="box-body">
                 <!-- <button id="print">Print</button> -->

                   <table id="example"  class="table table-bordered table-striped">
                     <thead>

                       <tr>
                   
                     
                       <th>User Id</th>
                       <th>IP</th>
                       <th></th>
                       <th></th>
                       
                       
                     
                     </tr>
                     </thead>
                     <tbody>                       
@if(!empty($data))
                       @foreach($data as $datas) 
                        <tr>                        
                       <td>{{$datas['user_id']}} </td>
                       <td>{{$datas['ip']}}</td>
                       <td>   <button type="button" class="btn btn-info btn-lg userdT" data-user-id ="{{$datas['id']}}" data-toggle="modal" data-target="#myModal">View</button>
                       </td>

                       <td><a href="{{url('/delete/'.$datas['id'])}}" class="btn btn-info btn-lg">Delete</a>
</td>

                        
                      </tr> 
                        @endforeach 
                        @else
                       <tr> No Data Found </tr>
                        @endif
                     </tbody>
                 
                   </table>
                 </div>
                 <!-- /.box-body -->
               </div>
               <!-- /.box -->

      </div>






      <!-- Modal -->


  
 


<div class="container">
 
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Cookies Data</h4>
        </div>
        <div class="modal-body">

           <table id="example"  class="table table-bordered table-striped">
                     <thead>

                       <tr>
                   
                     
                       
                       <th>Name</th>
                       <th>Value</th>
                       
                       
                     
                     </tr>
                     </thead>
                     <tbody class="getdata">    

                     </tbody>
                 
                   </table>
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>





@endsection



@section('javascript')
<script type="text/javascript">

$(document).ready(function(){
    $('.userdT').click(function(){
      var id = $(this).data("user-id");

     var url = "{{url('/cookiedata')}}";

        $.ajax({
            url: url+'/'+id,
            type: 'GET',  
            data: {'id':id},          
            success: function (data) {
                $('.getdata').html(data);
            }
        });
    });
});

</script>
@stop