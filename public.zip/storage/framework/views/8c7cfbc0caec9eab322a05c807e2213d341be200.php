<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
<head>

    <?php echo $__env->make('admin.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <?php echo $__env->make('admin.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                <?php if(!empty(Request::segment(1))): ?>
                <?php echo e(ucfirst(Request::segment(1))); ?>

                <?php endif; ?>
                
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url(''.'/'.Request::segment(1))); ?>"><i class="fa fa-dashboard"></i> <?php if(!empty(Request::segment(1))): ?>
                            <?php echo e(ucfirst(Request::segment(1))); ?>

                        <?php endif; ?></a></li>


                
            </ol>
        </section>

        <!-- Main content -->

            <section class="content">
            <?php echo $__env->yieldContent('content'); ?>

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('admin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.partials.rightside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>


<?php echo $__env->make('admin.partials.javascripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('javascript'); ?>


</body>
